@echo off
net session >nul 2>&1
if %errorlevel% neq 0 (
  echo Asking for admin permission...
  powershell -Command "Start-Process '%~f0' -Verb RunAs"
  exit /b
)
netsh advfirewall firewall delete rule name="EZ RTMP Server" >nul 2>&1
netsh advfirewall firewall add rule name="EZ RTMP Server" dir=in action=allow protocol=TCP localport=1935,8080 profile=any
echo.
echo Done. Other devices can now reach the server.
pause
